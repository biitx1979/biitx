#### ㊗️阳光正好，微风不燥，人间值得，未来可期！
### 1. TVBox 开源版  
- TVBox1.0.0 ，[GitHub社区](https://github.com/CatVodTVOfficial/TVBoxOSC) 根据官方代码仓生成的安卓应用。  
- 本地功能，只需要开启存储权限，在配置地址栏输入本地规则地址即可。  
- 设置——配置地址——输入你的站源规则——确定即可；  

### 2. 下载地址
 - [TVbox开源版](https://wws.lanzouv.com/b03j4ulyh#999)   
 - [欢迎志同道合的朋友加入---点击直接加入🐧裙](https://jq.qq.com/?_wv=1027&k=KhLg7JXX)  
